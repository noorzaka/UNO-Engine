package card;

public enum Color {
    RED, GREEN, BLUE, YELLOW, WILD
}
