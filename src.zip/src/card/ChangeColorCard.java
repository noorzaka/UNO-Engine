package card;

import game.Game;

public class ChangeColorCard extends WildCard {
    public ChangeColorCard(Color color, int priority) {
        super(color, priority);
    }

    @Override
    public void play(Game game) {
        // Implement ChangeColorCard-specific play logic
    }
}
