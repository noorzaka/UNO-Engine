package deck;

import card.Card;

import java.util.List;

public abstract class DeckInitializer {
    public abstract List<Card> initializeDeck();
}
