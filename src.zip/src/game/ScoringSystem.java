package game;

public class ScoringSystem {
    public void updateScore(Player player) {
        // Implement scoring logic
    }

    public int getScore(Player player) {
        // Implement score retrieval logic
        return 0;
    }
}
